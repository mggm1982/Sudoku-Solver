#include <iostream>
using namespace std;
// Printing the Sudoku board
void printBoard(int board[9][9]) {
    for(int i=0;i<9;i++) {
        for(int j = 0;j<9;j++) {
            cout<<board[i][j]<<" ";
        }
        cout<<endl;
    }
}

// Checking whether a number can be placed in a given cell
int isValid(int board[9][9], int row, int col, int num) {
    // First checking the row;
    for(int j = 0;j<9;j++) {
        if(board[row][j] == num) {
            return 0;
        }
    }
    // Then checking the column;
    for(int i=0;i<9;i++) {
        if(board[i][col] == num) {
            return 0;
        }
    }
//         
//  col   0 1 2   3 4 5   6 7 8
//      +-------+-------+-------+
// row 0|       |       |       |
// row 1| BOX 1 | BOX 2 | BOX 3 |
// row 2|       |       |       |
//      +-------+-------+-------+
// row 3|       |       |       |
// row 4| BOX 4 | BOX 5 | BOX 6 |
// row 5|       |       |       |
//      +-------+-------+-------+
// row 6|       |       |       |
// row 7| BOX 7 | BOX 8 | BOX 9 |
// row 8|       |       |       |
//      +-------+-------+-------+

    // Then checking the 3x3 box;
    int boxRowStart = row - row%3;
    int boxColStart = col - col%3;
    for(int i=boxRowStart;i<boxRowStart+3;i++) {
        for(int j=boxColStart;j<boxColStart+3;j++) {
            if(board[i][j] == num) {
                return 0;
            }
        }
    }
    return 1;

}

// Solving the Sudoku board using backtracking
int solveSudoku(int board[9][9]) {
    int row = -1;
    int col = -1;
    for(int i=0;i<9;i++) {
        for(int j=0;j<9;j++) {
            if(board[i][j] == 0) {
                row = i;
                col = j;
                break;
            }
        }
        if(row != -1) {
            break;
        }
    }
    if(row == -1) {
        return 1;
    }
    for(int num = 1;num<=9;num++) {
        if(isValid(board,row,col,num) == 1) {
            board[row][col] = num;
            int isSolved = solveSudoku(board);
            // Backtracking
            if(isSolved == 1) {
                return 1;
            }
            else {
                board[row][col] = 0;
            }
        }
        
        
    }
    // No number can be placed in the given position, so returning 0
    return 0;

}
int main() {
    int board[9][9] =
{
    {5, 3, 0, 0, 7, 0, 0, 0, 0},
    {6, 0, 0, 1, 9, 5, 0, 0, 0},
    {0, 9, 8, 0, 0, 0, 0, 6, 0},

    {8, 0, 0, 0, 6, 0, 0, 0, 3},
    {4, 0, 0, 8, 0, 3, 0, 0, 1},
    {7, 0, 0, 0, 2, 0, 0, 0, 6},

    {0, 6, 0, 0, 0, 0, 2, 8, 0},
    {0, 0, 0, 4, 1, 9, 0, 0, 5},
    {0, 0, 0, 0, 8, 0, 0, 7, 9}
};
    int a = solveSudoku(board);
    if(a == 1) {
        cout<<"The Sudoku board is solved successfully!"<<endl;
        printBoard(board);
    }
    else {
        cout<<"The Sudoku board cannot be solved!"<<endl;
    }
    return 0;


}


